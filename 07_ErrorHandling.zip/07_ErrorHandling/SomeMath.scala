
class SomeMath {
  def add(a: Int, b: Int): Int = {
    a + b
  }
}
