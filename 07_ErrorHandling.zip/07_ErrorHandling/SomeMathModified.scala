
class SomeMath {
  def add(a: Int, b: Int): Int = {
    if (a > 5)
      a - b
    else
      a + b
  }
}
