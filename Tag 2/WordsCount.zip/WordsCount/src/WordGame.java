import java.util.*;

public class WordGame {
    private Map<String, Integer> wordScores;

    public WordGame() {
        this.wordScores = new HashMap<>();
    }

    public void addWord(String word) {
        int score = calculateScore(word);
        wordScores.put(word, score);
    }

    public int calculateScore(String word) {
        int score = 0;
        for (char c : word.toCharArray()) {
            if (c != 'a' && c != 'A') { // 'a' and 'A' are not counted
                score += 1;
            }
        }
        return score;
    }

    public List<String> getWordsSortedByScore() {
        List<Map.Entry<String, Integer>> entries = new ArrayList<>(wordScores.entrySet());
        entries.sort((entry1, entry2) -> entry2.getValue().compareTo(entry1.getValue()));

        List<String> sortedWords = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : entries) {
            sortedWords.add(entry.getKey());
        }
        return sortedWords;
    }

    public void resetWords() {
        wordScores.clear();
    }

    public static void main(String[] args) {
        WordGame game = new WordGame();
        game.addWord("apple");
        game.addWord("banana");
        game.addWord("cherry");

        System.out.println("Words sorted by score: " + game.getWordsSortedByScore()); // [cherry, banana, apple]

        game.resetWords();
        System.out.println("Words after reset: " + game.getWordsSortedByScore()); // []
    }
}