import java.util.*;

public class CarRace {
    private Map<String, List<Integer>> lapTimes;

    public CarRace() {
        lapTimes = new HashMap<>();
    }

    public void addLapTime(String carId, int time) {
        lapTimes.putIfAbsent(carId, new ArrayList<>());
        lapTimes.get(carId).add(time);
    }

    public int getTotalTime(String carId) {
        List<Integer> times = lapTimes.get(carId);
        if (times == null || times.size() <= 1) return 0;

        return times.subList(1, times.size()).stream().mapToInt(Integer::intValue).sum();
    }

    public double getAverageTime(String carId) {
        List<Integer> times = lapTimes.get(carId);
        if (times == null || times.size() <= 1) return 0;

        List<Integer> relevantTimes = times.subList(1, times.size());
        int total = relevantTimes.stream().mapToInt(Integer::intValue).sum();
        return (double) total / relevantTimes.size();
    }

    public void resetCarLaps(String carId) {
        lapTimes.remove(carId);
    }

    public List<Integer> getCarLapTimes(String carId) {
        return lapTimes.get(carId);
    }

    public static void main(String[] args) {
        CarRace race = new CarRace();
        race.addLapTime("car1", 120);  // Warm-up lap
        race.addLapTime("car1", 110);
        race.addLapTime("car1", 115);
        race.addLapTime("car1", 112);

        System.out.println("Total time for car1: " + race.getTotalTime("car1") + " seconds"); // 337 seconds
        System.out.println("Average time for car1: " + race.getAverageTime("car1") + " seconds"); // 112.33 seconds
        System.out.println("Lap times for car1: " + race.getCarLapTimes("car1")); // [120, 110, 115, 112]

        race.resetCarLaps("car1");
        System.out.println("Lap times for car1 after reset: " + race.getCarLapTimes("car1")); // null
    }
}